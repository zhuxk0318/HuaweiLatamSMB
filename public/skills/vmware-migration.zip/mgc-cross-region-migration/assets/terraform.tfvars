# Fill these values before running terraform apply.
access_key  = ""
secret_key  = ""
domain_name = "HIS_luoliangbing"

# Source VMware SMS source ID
source_server_id = "3574494d-5e3d-40c1-9170-13075d7ac3dc"
source_region    = "la-north-2"

# Target: Mexico City2
target_region      = "la-north-2"
target_region_name = "LA-Mexico City2"
target_vpc_name    = "vpc-migration"

# Use a valid Mexico City2 image for target ECS bootstrap/network checks.
target_image_id    = "def7f676-e1e3-43c3-9098-e41f3324d566"
target_server_name = "vmware-to-mx2-migrated-fresh"

# Optional flavor override for target ECS. Keep empty for auto-select.
target_flavor_id      = ""
target_admin_password = "MgcMigr@te2026!"

eip_bandwidth_mbps = 100
root_volume_type   = "SSD"
data_volume_type   = "SSD"

# Official SMS endpoint for intl site docs
sms_endpoint = "https://sms.ap-southeast-3.myhuaweicloud.com"

# Migration method policy: force rsync for VMware source migration.
preferred_migration_method = "rsync"
enable_rsync_fallback      = true

# Source connectivity (VPN direct to VMware VM)
source_private_ip     = "192.168.229.128"
extra_peer_ips        = ["10.8.0.2", "192.168.229.128", "0.0.0.0/0"]
rsync_source_host     = "192.168.229.128"
rsync_source_port     = 22
rsync_source_user     = "root"
rsync_source_password = "Huawei@codex123"

# Target SSH for rsync fallback
rsync_target_host     = ""
rsync_target_port     = 22
rsync_target_user     = "root"
rsync_target_password = ""

# rsync staged migration phases: full -> incremental -> cutover
rsync_source_paths       = ["/"]
rsync_staging_dir        = "/tmp/mgc-rsync-stage"
rsync_incremental_rounds = 0
rsync_timeout_sec        = 7200
rsync_common_args        = "--numeric-ids --info=stats2,progress2 --partial"
rsync_excludes = [
  "/dev/*",
  "/proc/*",
  "/sys/*",
  "/tmp/*",
  "/run/*",
  "/mnt/*",
  "/media/*",
  "/lost+found",
  "/swapfile",
  "/var/tmp/*",
  "/var/run/*",
  "/boot/efi/*",
  "/etc/fstab",
  "/usr/bin/rsync",
  "/bin/rsync"
]
rsync_cutover_stop_cmd    = ""
rsync_cutover_start_cmd   = ""
rsync_target_finalize_cmd = ""

# Codex acts as VPN server and bridges source/target through VPC peering.
enable_vpn_bridge        = true
enable_target_vpn_client = false
vpn_server_public_ip     = "149.232.136.255"
vpn_server_port          = 1194
vpn_client_common_name   = "site-mx2-target"
vpn_client_static_ip     = "10.8.0.10"
