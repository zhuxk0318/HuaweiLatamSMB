import asyncio
import logging
import shlex

from .config import ExecutionConfig

logger = logging.getLogger(__name__)


def _is_obs_command(args: list[str]) -> bool:
    for arg in args:
        if arg.startswith("-"):
            continue
        return arg.lower() == "obs"
    return False


def _translate_obs_region(args: list[str], config: ExecutionConfig) -> list[str]:
    result = []
    region = None
    for arg in args:
        if arg.startswith("--cli-region="):
            region = arg.split("=", 1)[1]
        else:
            result.append(arg)

    if region:
        endpoint = config.obs_endpoint_template.format(region=region)
        result.append(f"-e={endpoint}")

    return result


def _build_full_command(command: str, config: ExecutionConfig) -> list[str]:
    cmd = [config.hcloud_binary]

    try:
        args = shlex.split(command)
    except ValueError:
        args = command.split()

    if _is_obs_command(args):
        args = _translate_obs_region(args, config)
        cmd.extend(args)
        return cmd

    cmd.extend(args)

    has_output_flag = any(
        arg.startswith("--cli-output") for arg in args
    )
    if not has_output_flag:
        cmd.append(f"--cli-output={config.cli_output}")

    return cmd


async def execute_command(
    command: str,
    config: ExecutionConfig,
) -> tuple[str, str, int]:
    """Run an hcloud/obs command asynchronously.

    This MUST be async (and awaited by callers) so that a long-running CLI
    invocation against the Huawei Cloud API does not block the MCP server's
    asyncio event loop. A blocking call here prevents the server from reading
    new requests from stdin or sending responses, which causes the client to
    cancel/timed-out requests and ultimately crashes the stdio transport with
    anyio.BrokenResourceError.
    """
    cmd = _build_full_command(command, config)
    logger.debug(f"Executing: {' '.join(cmd)}")

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        return "", f"hcloud binary not found: {config.hcloud_binary}", -1

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(),
            timeout=config.timeout_seconds,
        )
    except asyncio.TimeoutExpired:
        # Kill the timed-out child so it doesn't become a zombie.
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        return "", f"Command timed out after {config.timeout_seconds}s", -1

    stdout = stdout_bytes.decode(errors="replace") if stdout_bytes else ""
    stderr = stderr_bytes.decode(errors="replace") if stderr_bytes else ""
    return stdout, stderr, proc.returncode if proc.returncode is not None else -1
