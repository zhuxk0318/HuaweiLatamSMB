from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_drs_jobs",
        description="List DRS (Data Replication Service) jobs with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "job_type": {
                "type": "string",
                "description": "Filter by job type",
                "enum": ["migration", "sync", "cloudDataGuard"],
            },
            "status": {"type": "string", "description": "Filter by job status"},
            "name": {"type": "string", "description": "Filter by job name"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DRS", "ListJobs", p),
    ),
    ToolDefinition(
        name="hcloud_show_drs_job",
        description="Get details of a specific DRS job",
        params={
            "region": {"type": "string", "description": "Region"},
            "job_id": {"type": "string", "description": "DRS job ID"},
        },
        required=["region", "job_id"],
        build_command=lambda p: build_hcloud_command("DRS", "ShowJob", p),
    ),
    ToolDefinition(
        name="hcloud_list_drs_quotas",
        description="List DRS quotas for the tenant",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DRS", "ListQuotas", p),
    ),
]
