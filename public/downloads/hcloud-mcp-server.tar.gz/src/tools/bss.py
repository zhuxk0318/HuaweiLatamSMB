from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_bss_customer_orders",
        description="List BSS (Billing and Subscription) customer orders",
        params={
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
            "status": {"type": "string", "description": "Order status filter"},
        },
        required=[],
        build_command=lambda p: build_hcloud_command("BSSINTL", "ListCustomerOrders", p),
    ),
    ToolDefinition(
        name="hcloud_show_bss_account_balance",
        description="Show BSS (Billing and Subscription) account balance",
        params={},
        required=[],
        build_command=lambda p: build_hcloud_command("BSSINTL", "ShowAccountBalance", p),
    ),
    ToolDefinition(
        name="hcloud_list_bss_measurements",
        description="List BSS (Billing and Subscription) measurements",
        params={
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=[],
        build_command=lambda p: build_hcloud_command("BSSINTL", "ListMeasurements", p),
    ),
]
