from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_cci_namespaces",
        description="List CCI (Cloud Container Instance) namespaces",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CCI", "listCoreV1Namespace", p),
    ),
    ToolDefinition(
        name="hcloud_list_cci_deployments",
        description="List CCI (Cloud Container Instance) deployments",
        params={
            "region": {"type": "string", "description": "Region"},
            "namespace": {"type": "string", "description": "Namespace"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CCI", "listAppsV1DeploymentForAllNamespaces", p),
    ),
    ToolDefinition(
        name="hcloud_list_cci_pods",
        description="List CCI (Cloud Container Instance) pods",
        params={
            "region": {"type": "string", "description": "Region"},
            "namespace": {"type": "string", "description": "Namespace"},
            "deployment_name": {"type": "string", "description": "Deployment name"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CCI", "listCoreV1PodForAllNamespaces", p),
    ),
]
