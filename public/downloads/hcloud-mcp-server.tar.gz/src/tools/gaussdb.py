from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_gaussdb_instances",
        description="List GaussDB (openGauss) instances",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
            "db_type": {"type": "string", "description": "Database type filter"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("GaussDB", "ListInstances", p),
    ),
    ToolDefinition(
        name="hcloud_show_gaussdb_instance",
        description="Get details of a specific GaussDB (openGauss) instance",
        params={
            "region": {"type": "string", "description": "Region"},
            "instance_id": {"type": "string", "description": "GaussDB instance ID"},
        },
        required=["region", "instance_id"],
        build_command=lambda p: build_hcloud_command("GaussDB", "ShowInstance", p),
    ),
    ToolDefinition(
        name="hcloud_list_gaussdb_flavors",
        description="List available GaussDB (openGauss) instance flavors/specs",
        params={
            "region": {"type": "string", "description": "Region"},
            "db_type": {"type": "string", "description": "Database type filter"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("GaussDB", "ListFlavors", p),
    ),
    ToolDefinition(
        name="hcloud_list_gaussdb_datastores",
        description="List available GaussDB (openGauss) DB engine versions",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("GaussDB", "ListDatastores", p),
    ),
]
