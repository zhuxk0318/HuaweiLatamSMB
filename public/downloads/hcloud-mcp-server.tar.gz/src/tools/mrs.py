from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_mrs_clusters",
        description="List MRS (MapReduce Service) clusters",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("MRS", "ListClusters", p),
    ),
    ToolDefinition(
        name="hcloud_show_mrs_cluster",
        description="Get details of a specific MRS (MapReduce Service) cluster",
        params={
            "region": {"type": "string", "description": "Region"},
            "cluster_id": {"type": "string", "description": "MRS cluster ID"},
        },
        required=["region", "cluster_id"],
        build_command=lambda p: build_hcloud_command("MRS", "ShowCluster", p),
    ),
    ToolDefinition(
        name="hcloud_list_mrs_flavors",
        description="List available MRS (MapReduce Service) cluster flavors/specs",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("MRS", "ListFlavors", p),
    ),
]
