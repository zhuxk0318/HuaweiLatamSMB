from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_oms_tasks",
        description="List OMS (Object Storage Migration Service) tasks",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
            "status": {"type": "string", "description": "Filter by task status"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("OMS", "ListTasks", p),
    ),
    ToolDefinition(
        name="hcloud_show_oms_task",
        description="Get details of a specific OMS (Object Storage Migration Service) task",
        params={
            "region": {"type": "string", "description": "Region"},
            "task_id": {"type": "string", "description": "Task ID"},
        },
        required=["region", "task_id"],
        build_command=lambda p: build_hcloud_command("OMS", "ShowTask", p),
    ),
    ToolDefinition(
        name="hcloud_list_oms_sync_tasks",
        description="List OMS (Object Storage Migration Service) sync tasks",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("OMS", "ListSyncTasks", p),
    ),
]
