from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_er_routers",
        description="List ER (Enterprise Router) routers",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("ER", "ListEnterpriseRouters", p),
    ),
    ToolDefinition(
        name="hcloud_show_er_router",
        description="Get details of a specific ER (Enterprise Router) router",
        params={
            "region": {"type": "string", "description": "Region"},
            "router_id": {"type": "string", "description": "ER router ID"},
        },
        required=["region", "router_id"],
        build_command=lambda p: build_hcloud_command("ER", "ShowRouter", p),
    ),
    ToolDefinition(
        name="hcloud_list_er_route_tables",
        description="List route tables for a specific ER (Enterprise Router) router",
        params={
            "region": {"type": "string", "description": "Region"},
            "router_id": {"type": "string", "description": "ER router ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region", "router_id"],
        build_command=lambda p: build_hcloud_command("ER", "ListRouteTables", p),
    ),
    ToolDefinition(
        name="hcloud_list_er_attachments",
        description="List attachments for a specific ER (Enterprise Router) router",
        params={
            "region": {"type": "string", "description": "Region"},
            "router_id": {"type": "string", "description": "ER router ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region", "router_id"],
        build_command=lambda p: build_hcloud_command("ER", "ListAttachments", p),
    ),
]
