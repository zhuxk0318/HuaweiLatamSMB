from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_cbr_vaults",
        description="List CBR (Cloud Backup and Recovery) vaults",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CBR", "ListVault", p),
    ),
    ToolDefinition(
        name="hcloud_show_cbr_vault",
        description="Get details of a specific CBR (Cloud Backup and Recovery) vault",
        params={
            "region": {"type": "string", "description": "Region"},
            "vault_id": {"type": "string", "description": "Vault ID"},
        },
        required=["region", "vault_id"],
        build_command=lambda p: build_hcloud_command("CBR", "ShowVault", p),
    ),
    ToolDefinition(
        name="hcloud_list_cbr_backups",
        description="List CBR (Cloud Backup and Recovery) backups",
        params={
            "region": {"type": "string", "description": "Region"},
            "checkpoint_id": {"type": "string", "description": "Filter by checkpoint ID"},
            "resource_id": {"type": "string", "description": "Filter by resource ID"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CBR", "ListBackups", p),
    ),
    ToolDefinition(
        name="hcloud_list_cbr_policies",
        description="List CBR (Cloud Backup and Recovery) backup policies",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CBR", "ListPolicies", p),
    ),
]
