from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_sms_servers",
        description="List SMS (Server Migration Service) source servers",
        params={
            "region": {"type": "string", "description": "Region"},
            "state": {"type": "string", "description": "Filter by server state"},
            "name": {"type": "string", "description": "Filter by server name"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SMS", "ListServers", p),
    ),
    ToolDefinition(
        name="hcloud_show_sms_server",
        description="Get details of a specific SMS (Server Migration Service) source server",
        params={
            "region": {"type": "string", "description": "Region"},
            "server_id": {"type": "string", "description": "Server ID"},
        },
        required=["region", "server_id"],
        build_command=lambda p: build_hcloud_command("SMS", "ShowServer", p),
    ),
    ToolDefinition(
        name="hcloud_list_sms_tasks",
        description="List SMS (Server Migration Service) migration tasks",
        params={
            "region": {"type": "string", "description": "Region"},
            "state": {"type": "string", "description": "Filter by task state"},
            "name": {"type": "string", "description": "Filter by task name"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SMS", "ListTasks", p),
    ),
    ToolDefinition(
        name="hcloud_show_sms_task",
        description="Get details of a specific SMS (Server Migration Service) migration task",
        params={
            "region": {"type": "string", "description": "Region"},
            "task_id": {"type": "string", "description": "Task ID"},
        },
        required=["region", "task_id"],
        build_command=lambda p: build_hcloud_command("SMS", "ShowTask", p),
    ),
    ToolDefinition(
        name="hcloud_list_sms_migration_projects",
        description="List SMS (Server Migration Service) migration projects",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SMS", "ListMigprojects", p),
    ),
]
