from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_dws_clusters",
        description="List DWS (GaussDB Data Warehouse) clusters",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DWS", "ListClusters", p),
    ),
    ToolDefinition(
        name="hcloud_show_dws_cluster",
        description="Get details of a specific DWS (GaussDB Data Warehouse) cluster",
        params={
            "region": {"type": "string", "description": "Region"},
            "cluster_id": {"type": "string", "description": "DWS cluster ID"},
        },
        required=["region", "cluster_id"],
        build_command=lambda p: build_hcloud_command("DWS", "ShowCluster", p),
    ),
    ToolDefinition(
        name="hcloud_list_dws_flavors",
        description="List available DWS (GaussDB Data Warehouse) cluster flavors/specs",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DWS", "ListFlavors", p),
    ),
]
