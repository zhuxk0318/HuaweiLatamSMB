from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_vpn_gateways",
        description="List VPN gateways (VGWs) with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "vgw_id": {"type": "string", "description": "Filter by VPN gateway ID"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("VPN", "ListVgws", p),
    ),
    ToolDefinition(
        name="hcloud_show_vpn_gateway",
        description="Get details of a specific VPN gateway (VGW)",
        params={
            "region": {"type": "string", "description": "Region"},
            "vgw_id": {"type": "string", "description": "VPN gateway ID"},
        },
        required=["region", "vgw_id"],
        build_command=lambda p: build_hcloud_command("VPN", "ShowVgw", p),
    ),
    ToolDefinition(
        name="hcloud_list_vpn_connections",
        description="List VPN connections with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "vgw_id": {"type": "string", "description": "Filter by VPN gateway ID"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("VPN", "ListConnections", p),
    ),
    ToolDefinition(
        name="hcloud_show_vpn_connection",
        description="Get details of a specific VPN connection",
        params={
            "region": {"type": "string", "description": "Region"},
            "connection_id": {"type": "string", "description": "VPN connection ID"},
        },
        required=["region", "connection_id"],
        build_command=lambda p: build_hcloud_command("VPN", "ShowConnection", p),
    ),
    ToolDefinition(
        name="hcloud_list_vpn_ike_policies",
        description="List VPN IKE policies",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("VPN", "ListIkePolicies", p),
    ),
    ToolDefinition(
        name="hcloud_list_vpn_ipsec_policies",
        description="List VPN IPsec policies",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("VPN", "ListIpsecPolicies", p),
    ),
    ToolDefinition(
        name="hcloud_list_vpn_customer_gateways",
        description="List VPN customer gateways (CGWs) with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("VPN", "ListCgws", p),
    ),
]
