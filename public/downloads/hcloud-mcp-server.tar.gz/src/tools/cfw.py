from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_cfw_firewalls",
        description="List CFW (Cloud Firewall) firewalls",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CFW", "ListFirewalls", p),
    ),
    ToolDefinition(
        name="hcloud_list_cfw_acl_rules",
        description="List CFW (Cloud Firewall) ACL rules",
        params={
            "region": {"type": "string", "description": "Region"},
            "object_id": {"type": "string", "description": "Protection object ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CFW", "ListAclRules", p),
    ),
    ToolDefinition(
        name="hcloud_list_cfw_service_rules",
        description="List CFW (Cloud Firewall) service rules",
        params={
            "region": {"type": "string", "description": "Region"},
            "object_id": {"type": "string", "description": "Protection object ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Page offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CFW", "ListServiceRules", p),
    ),
]
