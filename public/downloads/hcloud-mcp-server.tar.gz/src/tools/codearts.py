from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_codearts_projects",
        description="List CodeArts projects",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("ProjectMan", "ListProjects", p),
    ),
    ToolDefinition(
        name="hcloud_list_codearts_repositories",
        description="List CodeArts repositories in a project",
        params={
            "region": {"type": "string", "description": "Region"},
            "project_id": {"type": "string", "description": "CodeArts project ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CodeArtsRepo", "ListRepositories", p),
    ),
    ToolDefinition(
        name="hcloud_list_codearts_pipelines",
        description="List CodeArts pipelines in a project",
        params={
            "region": {"type": "string", "description": "Region"},
            "project_id": {"type": "string", "description": "CodeArts project ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("CodeArtsPipeline", "ListPipelines", p),
    ),
]
