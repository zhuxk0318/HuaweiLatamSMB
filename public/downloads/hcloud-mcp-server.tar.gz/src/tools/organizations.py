from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_organizations_ous",
        description="List Organizations organizational units (OUs)",
        params={
            "region": {"type": "string", "description": "Region"},
            "parent_id": {"type": "string", "description": "Parent OU ID"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("Organizations", "ListOUs", p),
    ),
    ToolDefinition(
        name="hcloud_list_organizations_accounts",
        description="List Organizations accounts",
        params={
            "region": {"type": "string", "description": "Region"},
            "parent_id": {"type": "string", "description": "Parent OU ID"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("Organizations", "ListAccounts", p),
    ),
    ToolDefinition(
        name="hcloud_list_rgc_control_policies",
        description="List RGC control policies",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("RGC", "ListControls", p),
    ),
]
