from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_swr_namespaces",
        description="List SWR (Software Repository for Containers) namespaces with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SWR", "ListNamespaces", p),
    ),
    ToolDefinition(
        name="hcloud_list_swr_repositories",
        description="List SWR repositories with optional filters",
        params={
            "region": {"type": "string", "description": "Region"},
            "namespace": {"type": "string", "description": "Filter by namespace"},
            "limit": {"type": "integer", "description": "Max number of results"},
            "offset": {"type": "integer", "description": "Offset for pagination"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SWR", "ListNamespaceRepositories", p),
    ),
    ToolDefinition(
        name="hcloud_list_swr_tags",
        description="List tags for a specific SWR repository",
        params={
            "region": {"type": "string", "description": "Region"},
            "repository": {"type": "string", "description": "Repository name"},
            "namespace": {"type": "string", "description": "Namespace the repository belongs to"},
        },
        required=["region", "repository"],
        build_command=lambda p: build_hcloud_command("SWR", "ListNamespaceTags", p),
    ),
    ToolDefinition(
        name="hcloud_show_swr_domain",
        description="Show the SWR login domain for the tenant",
        params={
            "region": {"type": "string", "description": "Region"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("SWR", "ListDomainNames", p),
    ),
]
