from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_lts_groups",
        description="List LTS (Log Tank Service) log groups",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("LTS", "ListLogGroups", p),
    ),
    ToolDefinition(
        name="hcloud_list_lts_streams",
        description="List LTS (Log Tank Service) log streams in a log group",
        params={
            "region": {"type": "string", "description": "Region"},
            "log_group_id": {"type": "string", "description": "Log group ID"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("LTS", "ListLogStreams", p),
    ),
]
