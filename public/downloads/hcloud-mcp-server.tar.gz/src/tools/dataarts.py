from .registry import ToolDefinition, build_hcloud_command

TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="hcloud_list_dataarts_workspaces",
        description="List DataArts workspaces",
        params={
            "region": {"type": "string", "description": "Region"},
            "limit": {"type": "integer", "description": "Max results"},
            "offset": {"type": "integer", "description": "Pagination offset"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DataArtsStudio", "ListWorkspaces", p),
    ),
    ToolDefinition(
        name="hcloud_list_dataarts_catalogs",
        description="List DataArts catalogs in a workspace",
        params={
            "region": {"type": "string", "description": "Region"},
            "workspace_id": {"type": "string", "description": "DataArts workspace ID"},
        },
        required=["region"],
        build_command=lambda p: build_hcloud_command("DataArtsStudio", "ListCatalogs", p),
    ),
]
